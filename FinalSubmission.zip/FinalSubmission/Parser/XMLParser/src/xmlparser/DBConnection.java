package xmlparser;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import oracle.jdbc.driver.*;


public class DBConnection {
	
	private static Connection _connection;
	private static String _username="grag";
	private static String _password="gocool12";
	
	/**
	 * @return the connection object for the given Database parameters
	 * @throws SQLException
	 */
	public static Connection openConnection() throws SQLException{
		try{
		Class.forName("oracle:jdbc.driver.OracleDriver");
		DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
		String url = "jdbc:oracle:thin@fling@seas.upenn.edu:1521:cis";
	
		_connection = DriverManager.getConnection(url, _username, _password);
		return _connection;
		}
		
		catch(ClassNotFoundException e){
			return null;
		}
	}
	
	
	public static boolean closeConnection(){
		try{
			if(_connection != null)
				_connection.close();
			return true;
		}
		catch(Exception e){
			return false;
		}
	}
	
}
