package xmlparser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;	
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * @author gokul
 *
 */
public class AtheleteParser {


	private File atheleteXml;
	private DocumentBuilder docBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;
	private int count;

	//hash table of records for corresponding table
	private HashMap<Integer,AtheletePersonalInfo> athlete_personalinfo = new HashMap<Integer,AtheletePersonalInfo>();

	//hash table for user name and uid
	private HashMap<String,Integer> athelete_userinfo = new HashMap<String,Integer>();
	
	//hash table for events
	private ArrayList<Events> events = new ArrayList<Events>();

	//list of athelete medalswon for different events
	private ArrayList<Atheleteparticipation> athlete_participation = new ArrayList<Atheleteparticipation>();

	/**
	 * @param fileName
	 */
	public AtheleteParser(String fileName){
		if(fileName != null){
			initialize(fileName);
		}
	}

	private void initialize(String fileName){
		try{
			atheleteXml = new File(fileName);
			dbFactory = DocumentBuilderFactory.newInstance();
			docBuilder = dbFactory.newDocumentBuilder();
			doc = docBuilder.parse(atheleteXml);
			doc.getDocumentElement().normalize();
		}
		catch(Exception e){

		}

	}

	public void parseNodes(){

		//System.out.println(doc.getDocumentElement().getNodeName());
		parseAthleteRecords();
		System.out.println(count);
	}


	public void parseAthleteRecords(){
		NodeList nodes = doc.getElementsByTagName("Record");
		for(int i = 0; i < nodes.getLength(); ++i){

			Node currentNode = nodes.item(i);

			if(currentNode.getNodeType() == Node.ELEMENT_NODE){
				Element element = (Element)currentNode;

				parseAtheletePersonalInfo(i,element);
				parseEventsAndMedalRecords(i,element);	
			}

		}

	}

	/**
	 * parses the athelete information.
	 * @param aid
	 * @param elemnt	
	 */
	private void parseAtheletePersonalInfo(int aid, Element elemnt){

		AtheletePersonalInfo athperinfo = new AtheletePersonalInfo();
		athperinfo.aid = aid;
		athperinfo.uid = athperinfo.aid;
		athperinfo.name = parseName(elemnt).trim();
		addUserName(athperinfo.aid, athperinfo.name);
		
		athperinfo.gender = parseGender(elemnt).trim();
		//		athperinfo.gender = getValue("Gender",elemnt);
		String parsedDOB = getValue("DOB",elemnt).trim();
		String[] birthdetails =  parseBirthDetails(parsedDOB);

		athperinfo.dob = birthdetails[0];
		athperinfo.bcity = birthdetails[1];
		athperinfo.bstate = birthdetails[2];
		athperinfo.country = parseCountry(elemnt).trim();
		athperinfo.sport = parseSport(elemnt).trim();
		this.athlete_personalinfo.put(aid, athperinfo);
	}


	private void addUserName(int uid, String name) {
	
		int runningCounter = 0;
		String key = name.trim().split(" ")[0].toLowerCase();
		String newKey = key;
		while(this.athelete_userinfo.containsKey(newKey)){
			newKey = key + runningCounter;
			runningCounter++;
		}
		athelete_userinfo.put(newKey, uid);
	}

	private void checkForNumber(String dob, String par, String bcity) {

		Pattern p = Pattern.compile("[0-9]+");
		Matcher m = p.matcher(bcity);
		if(m.find()){
			System.out.println(dob + " ::" + par + "::" +  bcity);
		}
	}

	private String parseSport(Element elemnt) {
		String result = getValue("Sport",elemnt).trim();
		if(result.toLowerCase().contains("medals")){
			result = result.substring(0,result.indexOf("Medals")).trim();
		}
		if(result.toLowerCase().contains("related")){
			result = result.substring(0,result.indexOf("Related")).trim();
		}
		if(result.toLowerCase().contains("other")){
			result = result.substring(0,result.indexOf("Other")).trim();
		}
		return removeNonAlphabets(result);
	}

	private String parseCountry(Element elemnt) {

		String result = getValue("Country",elemnt);
		result = removeNonAlphabets(result);
		return result;
	}

	private String parseGender(Element elemnt) {
		count++;
		String result = getValue("Gender",elemnt);
		if(result.toLowerCase().contains("female")) return "Female";
		else return "Male";
	}

	/**
	 * @param element - the root element "Record"
	 */
	private void parseEventsAndMedalRecords(int aid, Element element){
		NodeList medalHistory = element.getElementsByTagName("Medal_history");
		for(int i = 0; i < medalHistory.getLength();++i){
			Element curr_mdlhistory = (Element)(Element)medalHistory.item(i);
			int evntid  = parseEvents(curr_mdlhistory);
			this.parseAthleteParticipation(aid, evntid, curr_mdlhistory);
		}

	}


	/**
	 * @param elemnt
	 * @return the event id of the event the athlete participated
	 */
	private int parseEvents(Element elemnt){
		Events evnt = new Events();
		//evnt.evnt_name = getValue("Event",elemnt);
		evnt.evnt_name = getEventName(elemnt);
		String gameDetails = getValue("Games",elemnt);
		evnt.city = getCityName(elemnt);
		String[] yrSeason = gameDetails.split(" ");
		evnt.year = yrSeason[0];
		evnt.season = yrSeason[1];

		for(Events ev : events){
			if(ev.equals(evnt)) 
				return ev.eventid;
		}
		evnt.eventid = events.size();
		events.add(evnt);
		return evnt.eventid;

	}



	private String getCityName(Element elemnt) {
		String result = getValue("City",elemnt).trim();
		if(result.contains("'"))
			result = result.replaceAll("'", "");
		return result;
	}

	private String getEventName(Element elemnt) {
		
		String result = getValue("Event",elemnt);
		result = result.replaceAll("'", "");
		return result;
		
	}

	private void parseAthleteParticipation(int aid, int eid, Element element){
		Atheleteparticipation ap = new Atheleteparticipation();

		String agePresent = getValue("Age",element);
		ap.age =  agePresent != null ? Integer.parseInt(agePresent) : -1;
		ap.aid = aid;
		ap.eventid = eid;
		ap.rank = getValue("Rank",element);
		
		ap.team = getValue("Team",element);
		if(ap.team == null) ap.team = "None";
		if(ap.team != null && ap.team.contains("'")){
			ap.team = ap.team.replaceAll("'", "");
		}
		ap.medalswon = getValue("Medal",element);
		if(ap.medalswon == null) ap.medalswon = "None";
		this.athlete_participation.add(ap);
	}


	/**
	 * @param tag
	 * @param element
	 * @return the value of the xml tag
	 */
	private String getValue(String tag, Element element) {
		//NodeList ns = element.getElementsByTagName("MedalHistory");
		NodeList nodes = element.getElementsByTagName(tag).item(0).getChildNodes();
		Node node = (Node) nodes.item(0);
		if(node != null){
			return node.getNodeValue();
		}
		else return null;
	}



	private String parseName(Element element){

		String result = "";
		String parsedValue = getValue("Full_Name",element);
		if(parsedValue.toLowerCase().contains("nickname")){
			parsedValue = parsedValue.substring(0,parsedValue.toLowerCase().indexOf("nickname"));
		}
		result = removeNonAlphabets(parsedValue);
		return result;

	}	


	private String removeNonAlphabets(String s){
		String newS = s;
		Pattern p = Pattern.compile("[^A-Za-z ]+");
		Matcher m = p.matcher(s);
		if(m.find()){
			newS = m.replaceAll("");
		}
		return newS;
	}

	private boolean containsnonASCIICharacters(String s){

		Pattern p = Pattern.compile("[^A-Za-z0-9-. ]+");
		Matcher m = p.matcher(s);
		return m.find();
	}


	private String[] parseBirthDetails(String birthdetails){

		//System.out.println(birthdetails);


		String[] bdetails = new String[3];
		if(birthdetails.contains("name:")){
			bdetails[0] = bdetails[1] = "Not in records";
			bdetails[2] = "Not in records";
			return bdetails;
		}

		String[] arrBirthDetails = birthdetails.trim().split(",");
		if(arrBirthDetails.length == 6){
			if(arrBirthDetails[1].contains(" in ")){
				bdetails[0] = arrBirthDetails[0] + "," + arrBirthDetails[1].substring(0,arrBirthDetails[1].indexOf("in")).trim();
				bdetails[1] = arrBirthDetails[3].trim();
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[4].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else if(arrBirthDetails[0].contains(" in ")){
				bdetails[0] = arrBirthDetails[0].substring(0,arrBirthDetails[0].indexOf(" in "));
				bdetails[1] = arrBirthDetails[3].trim();
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[4].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else{
				bdetails[0] = "Not in records";
				bdetails[1] = "Not in records";
				bdetails[2] = arrBirthDetails[4].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
		}
		else if(arrBirthDetails.length == 5){
			if(arrBirthDetails[1].contains(" in ")){
				bdetails[0] = arrBirthDetails[0] + "," + arrBirthDetails[1].substring(0,arrBirthDetails[1].indexOf("in")).trim();
				bdetails[1] = arrBirthDetails[2].trim();
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[3].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else if(arrBirthDetails[0].contains(" in ")){
				bdetails[0] = arrBirthDetails[0].substring(0,arrBirthDetails[0].indexOf(" in "));
				bdetails[1] = arrBirthDetails[2].trim();
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[3].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else{
				bdetails[0] = "Not in records";
				bdetails[1] = "Not in records";
				bdetails[2] = arrBirthDetails[3].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
		}
		else if(arrBirthDetails.length == 4){
			if(arrBirthDetails[1].contains(" in ")){
				bdetails[0] = arrBirthDetails[0] + "," + arrBirthDetails[1].substring(0,arrBirthDetails[1].indexOf("in")).trim();
				bdetails[1] = arrBirthDetails[1].substring(arrBirthDetails[1].indexOf("in")+2).trim();
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[2].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else if(arrBirthDetails[0].contains(" in ")){
				bdetails[0] = arrBirthDetails[0].substring(0,arrBirthDetails[0].indexOf(" in "));
				bdetails[1] = arrBirthDetails[0].substring(arrBirthDetails[0].indexOf(" in ")+ 4);
				if(containsnonASCIICharacters(bdetails[1])){
					bdetails[1] = "Not in records";	
				}
				bdetails[2] = arrBirthDetails[2].trim();
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}
			else{
				bdetails[0] = "Not in records";
				bdetails[1] = "Not in records";
				bdetails[2] = arrBirthDetails[2];
				if(containsnonASCIICharacters(bdetails[2])){
					bdetails[2] = "Not in records";	
				}
			}		
		}
		else if(arrBirthDetails.length == 3){

			if(arrBirthDetails[1].contains(" in ")){
				bdetails[0] = arrBirthDetails[0] + "," + arrBirthDetails[1].substring(0,arrBirthDetails[1].indexOf("in")).trim();
				bdetails[1] = arrBirthDetails[1].substring(arrBirthDetails[1].indexOf("in")+2).trim();
				bdetails[2] = "Not in records";
			}
			else if(arrBirthDetails[0].contains(" in ")){
				bdetails[0] = arrBirthDetails[0].substring(0,arrBirthDetails[0].indexOf(" in "));
				bdetails[1] = arrBirthDetails[0].substring(arrBirthDetails[0].indexOf(" in ") + 4);
				bdetails[2] = arrBirthDetails[1].trim();
			}
			else if(arrBirthDetails[1].contains("Title:")){
				bdetails[0] = arrBirthDetails[0] + arrBirthDetails[1].substring(0,arrBirthDetails[1].indexOf("Title:"));
				bdetails[1] = "Not in records";
				bdetails[2] = "Not in records";
			}
			else{
				bdetails[0] = "Not in records";
				bdetails[1] = arrBirthDetails[0];
				bdetails[2] = arrBirthDetails[1];
			}
			for(int i = 0; i < bdetails.length;++i){
				if(containsnonASCIICharacters(bdetails[i]))
					bdetails[i] = "Not in records";
			}
		}
		else if(arrBirthDetails.length == 2){
			bdetails[0] = arrBirthDetails[0] + "," + arrBirthDetails[1].trim();

			bdetails[1] = "Not in records";
			bdetails[2] = "Not in records";
		}
		else if(arrBirthDetails.length == 1){
			bdetails[0] = arrBirthDetails[0].trim();
			bdetails[1] = "Not in records";
			bdetails[2] = "Not in records";
		}
		else{
		}
		return bdetails;
	}



	public void printAtheleteInfo(){
		AtheletePersonalInfo a = this.athlete_personalinfo.get(0);
		System.out.println();
		System.out.println(a.aid);
		System.out.println(a.name);
		System.out.println(a.bcity);
		System.out.println(a.bstate);
		System.out.println(a.country);
		System.out.println(a.dob);
		System.out.println(a.sport);
	}

	public void printEventsInfo(){
		System.out.println();
		Events e = this.events.get(0);
		System.out.println(e.eventid);
		System.out.println(e.evnt_name);
		System.out.println(e.season);
		System.out.println(e.year);
	}

	public void printAthleteParticipationInfo(){
		Atheleteparticipation a = this.athlete_participation.get(0);
		System.out.println();
		System.out.println(a.age);
		System.out.println(a.aid);
		System.out.println(a.eventid);
		System.out.println(a.medalswon);
		System.out.println(a.rank);
		System.out.println(a.team);
	}

	public void writeToFile(){
		writeToUserTable();
		writeToAtheletePersonalInfoScript();
		writeToEventsScript();
		writeToAtheleteParticipationScript();
	}


	private void writeToUserTable() {
		StringBuffer content = new StringBuffer();

		String query = "INSERT INTO USERLIST VALUES(%s,'%s','%s');\n";
		int uid;
		for(String username : this.athelete_userinfo.keySet()){
			uid = athelete_userinfo.get(username);
			content.append(String.format(query, uid,username,username));
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/userlist.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}

		
	}

	private void writeToAtheletePersonalInfoScript(){

		StringBuffer content = new StringBuffer();

		for(AtheletePersonalInfo api : athlete_personalinfo.values()){
			content.append(api.toString());
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/atheletepersonalinfo.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}

	}



	private void writeToEventsScript(){
		StringBuffer content = new StringBuffer();

		for(Events e : events){
			content.append(e.toString());
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/events.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}

	}

	private void writeToAtheleteParticipationScript(){
		StringBuffer content = new StringBuffer();

		for(Atheleteparticipation ap: athlete_participation ){
			content.append(ap.toString());
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/athleteparticipationinfo.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}

	}

	private class AtheletePersonalInfo{

		public String name, gender,dob,bcity,bstate,country,sport;
		public int aid,uid;	


		@Override
		public String toString(){
			String updateSt = "INSERT INTO ATHELETEPERSONALINFO VALUES(" + aid + "," +  uid + "," + "\'" + name + "\'" + "," + "\'" + gender + "\'"
					+ "," +  "\'" + dob + "\'" +  "," + "\'" + bcity + "\'" +  "," + "\'" + bstate + "\'" + "," + "\'" + country + "\'"
					+ "," +  "\'" + sport + "\'" + ")" + ";\n";

			return updateSt;
		}
	}

	private class Events{

		public String year,season, city, evnt_name;
		public int eventid;

		@Override
		public boolean equals(Object that){
			if (!(that instanceof Events)) return false;
			else{
				Events tht = (Events)that;
				if(this.year.equals(tht.year) && this.season.equals(tht.season) && 
						this.evnt_name.equals(tht.evnt_name))
					return true;
				return false;
			}
		}


		@Override
		public String toString(){
			String updateSt = "INSERT INTO EVENTS VALUES(" + eventid + "," + year  + "," + "\'" + season + "\'"
					+ "," +  "\'" + city + "\'" + "," + "\'" + evnt_name + "\'" + ")" + ";\n";

			return updateSt;
		}
	}

	private class Atheleteparticipation{

		public String team,rank,medalswon;
		public int aid, eventid,age;


		@Override
		public String toString(){
			String updateSt = "INSERT INTO ATHELETEPARTICIPATION VALUES(" + aid + "," +  eventid + "," +  age + "," +  "\'" + team + "\'"
					+ "," +  "\'" + rank + "\'" + "," +"\'" + medalswon + "\'" + ")" + ";\n";

			return updateSt;
		}
	}



}
