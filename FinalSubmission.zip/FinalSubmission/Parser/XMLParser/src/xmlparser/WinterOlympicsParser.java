package xmlparser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class WinterOlympicsParser {

	private File winterOlympics;
	private DocumentBuilder docBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;
	private Node root;
	private static ArrayList<WinterOlympicsRecord> win_olymp 
	= new ArrayList<WinterOlympicsRecord>();

	public static Map<String,Integer> a_countries;

	public WinterOlympicsParser(String fileName){
		winterOlympics = new File(fileName);
		initialize();
	}

	private void initialize(){
		try{
			dbFactory = DocumentBuilderFactory.newInstance();
			docBuilder = dbFactory.newDocumentBuilder();
			doc = docBuilder.parse(winterOlympics);
			doc.getDocumentElement().normalize();
			root = (Node) doc.getDocumentElement();
			a_countries = new HashMap<String,Integer>(SummerOlympicsParser.countries);

		}
		catch(Exception e){
			System.out.println("printing error message");
			e.printStackTrace();
		}
	}


	public void parseWinterOlympics(){
		parseOlympicsRecord();
	}


	/**
	 * The method parses the  summer olympics record stats
	 * It iterates through medal node by year and parses
	 * the records accordingly.
	 */
	private void parseOlympicsRecord(){

		//System.out.println(root.getChildNodes().getLength());
		NodeList children = root.getChildNodes();

		for(int i = 0; i < children.getLength(); ++i){
			Node olympicRecord = (Node) children.item(i);

			if(olympicRecord.getNodeType() == Node.ELEMENT_NODE)
				parseOlympicsRecordsByYear(olympicRecord);
		}
	}

	private void parseOlympicsRecordsByYear(Node olympic){

		Element olympicRecyr = (Element) olympic;
		int year = getYear(olympicRecyr);
		NodeList countriesRecord = olympicRecyr.getElementsByTagName("record");
		System.out.println(countriesRecord.getLength());
		WinterOlympicsRecord rec;

		for(int j = 0; j < countriesRecord.getLength();++j){

			rec = addCountryDetails(countriesRecord.item(j),year);
			win_olymp.add(rec);
		}

	}

	private int getYear(Element olympicyear){

		return Integer.parseInt(olympicyear.getNodeName().trim().split("_")[1]);

	}

	private WinterOlympicsRecord addCountryDetails(Node record, int year){

		Element re = (Element) record;
		WinterOlympicsRecord r = new WinterOlympicsRecord();

		r.year = year;
		r.rnk = Integer.parseInt(getValue("rk",re));
		String cntry = getValue("country", re);
		r.cid = getCountryId(cntry);
		r.gold = Integer.parseInt(getValue("gold",re));
		r.silver = Integer.parseInt(getValue("silver",re));
		r.bronze = Integer.parseInt(getValue("bronze",re));
		r.total = Integer.parseInt(getValue("total",re));
		return r;
	}

	private String getValue(String nodename, Element e){

		NodeList nodes = e.getElementsByTagName(nodename);

		return nodes.item(0).getFirstChild().getNodeValue().trim();
	}

	private int getCountryId(String country){

		String key = country.replaceAll("'", "");
		if(a_countries.containsKey(key)) return a_countries.get(key);
		else {
			int cid = a_countries.size();
			a_countries.put(key, cid);
			return cid;
		}
	}

	public void writeToWinterOlympicsScript(){

		StringBuffer content = new StringBuffer();

		for(WinterOlympicsRecord sop : win_olymp){
			content.append(sop.toString());
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/winterolympics.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}



	}

	public void writeToCountriesScript(){
		StringBuffer content = new StringBuffer();

		String query = "INSERT INTO COUNTRIES VALUES(%s,'%s');\n";
		for(String key : a_countries.keySet()){
			content.append(String.format(query, a_countries.get(key),key));
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/countries.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}

	}


	private class WinterOlympicsRecord{
		int cid, year, rnk, gold,silver, bronze, total;


		@Override
		public String toString(){
			String updateSt = "INSERT INTO WINTEROLYMPICS VALUES(" 
					+ cid + "," + rnk + "," + year + "," + gold + "," 
					+ silver + "," + bronze + "," + total
					+ ");\n";

			return updateSt;
		}
	}
}
