package xmlparser;

import java.io.FileNotFoundException;

/**
 * @author gokul
 *
 */
public class XMLParserMain {

	/**
	 * @param args
	 * @throws FileNotFoundException
	 */
	public static void main(String[] args) throws FileNotFoundException{

		if(args.length == 0) throw new FileNotFoundException();

				AtheleteParser aparser = new AtheleteParser(args[0]);
				aparser.parseNodes();
				aparser.writeToFile();

//		SummerOlympicsParser sop = new SummerOlympicsParser(args[0]);
//		sop.parseSummerOlympics();
//		sop.writeToSummerOlympicsScript();
//		WinterOlympicsParser wop = new WinterOlympicsParser(args[1]);
//		wop.parseWinterOlympics();
//		wop.writeToWinterOlympicsScript();
//		wop.writeToCountriesScript();


	}
}
