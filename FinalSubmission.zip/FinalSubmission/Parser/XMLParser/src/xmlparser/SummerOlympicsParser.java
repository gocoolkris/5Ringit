package xmlparser;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;


public class SummerOlympicsParser {

	private File summerOlympics;
	private DocumentBuilder docBuilder;
	private DocumentBuilderFactory dbFactory;
	private Document doc;
	private Node root;
	public static Map<String,Integer> countries = new HashMap<String,Integer>();
	private static ArrayList<SummerOlympicsRecord> sum_olymp 
	= new ArrayList<SummerOlympicsRecord>();

	public SummerOlympicsParser(String fileName){
		summerOlympics = new File(fileName);
		initialize();
	}

	private void initialize(){
		try{
			dbFactory = DocumentBuilderFactory.newInstance();
			docBuilder = dbFactory.newDocumentBuilder();
			doc = docBuilder.parse(summerOlympics);
			doc.getDocumentElement().normalize();
			root = (Node) doc.getDocumentElement();

		}
		catch(Exception e){
			System.out.println("printing error message");
			e.printStackTrace();
		}
	}


	public void parseSummerOlympics(){
		parseOlympicsRecord();
	}


	/**
	 * The method parses the  summer olympics record stats
	 * It iterates through medal node by year and parses
	 * the records accordingly.
	 */
	private void parseOlympicsRecord(){

		//System.out.println(root.getChildNodes().getLength());
		NodeList children = root.getChildNodes();

		for(int i = 0; i < children.getLength(); ++i){
			Node olympicRecord = (Node) children.item(i);

			if(olympicRecord.getNodeType() == Node.ELEMENT_NODE)
				parseOlympicsRecordsByYear(olympicRecord);
		}
	}

	private void parseOlympicsRecordsByYear(Node olympic){

		Element olympicRecyr = (Element) olympic;
		int year = getYear(olympicRecyr);
		NodeList countriesRecord = olympicRecyr.getElementsByTagName("record");
		System.out.println(countriesRecord.getLength());
		SummerOlympicsRecord rec;

		for(int j = 0; j < countriesRecord.getLength();++j){

			rec = addCountryDetails(countriesRecord.item(j),year);
			sum_olymp.add(rec);
		}

	}

	private int getYear(Element olympicyear){

		return Integer.parseInt(olympicyear.getNodeName().trim().split("_")[1]);

	}

	private SummerOlympicsRecord addCountryDetails(Node record, int year){

		Element re = (Element) record;
		SummerOlympicsRecord r = new SummerOlympicsRecord();

		r.year = year;
		r.rnk = Integer.parseInt(getValue("rk",re));
		String cntry = getValue("country", re);
		r.cid = getCountryId(cntry);
		System.out.println(r.year + "\t" + r.cid+ "\t"+ cntry);
		r.gold = Integer.parseInt(getValue("gold",re));
		r.silver = Integer.parseInt(getValue("silver",re));
		r.bronze = Integer.parseInt(getValue("bronze",re));
		r.total = Integer.parseInt(getValue("total",re));
		/*
		NodeList rec_item =  re.getChildNodes();
		SummerOlympicsRecord r = new SummerOlympicsRecord();
		r.year = year;
		for(int i = 0; i < rec_item.getLength();++i){
			Node tag =  rec_item.item(i);
			if(tag.getNodeType() == Node.ELEMENT_NODE){
				switch(tag.getNodeName().toLowerCase()){

				case "rk":
					System.out.println(tag.getNodeValue().trim());
					r.rnk = Integer.parseInt(tag.getNodeValue().trim());
					break;
				case "country":
					r.cid = getCountryId(tag.getNodeValue());
					break;
				case "gold":
					r.gold = Integer.parseInt(tag.getNodeValue().trim());
					break;
				case "silver":
					r.silver = Integer.parseInt(tag.getNodeValue().trim());
					break;
				case "bronze":
					r.bronze = Integer.parseInt(tag.getNodeValue().trim());
					break;
				case "total":
					r.total = Integer.parseInt(tag.getNodeValue().trim());
					break;	
				default:
					break;
				}
			}
		} */
		return r;
	}

	private String getValue(String nodename, Element e){

		NodeList nodes = e.getElementsByTagName(nodename);
		System.out.println(nodes.item(0).getNodeName());
		return nodes.item(0).getFirstChild().getNodeValue().trim();
	}

	private int getCountryId(String country){

		String key = country.replaceAll("'", "");
		if(countries.containsKey(key)) return countries.get(key);
		else {
			int cid = countries.size();
			countries.put(key, cid);
			return cid;
		}
	}

	public void writeToSummerOlympicsScript(){

		StringBuffer content = new StringBuffer();

		for(SummerOlympicsRecord sop : sum_olymp){
			content.append(sop.toString());
		}

		try{

			File file = new File("/home/gokul/CIS550/5Ringit/summerolympics.sql");
			if(!file.exists()) file.createNewFile();
			FileWriter fw = new FileWriter(file.getAbsoluteFile());
			BufferedWriter bw = new BufferedWriter(fw);
			bw.write(content.toString());
			bw.close();


		}
		catch(Exception e){}



	}




	private class SummerOlympicsRecord{
		int cid, year, rnk, gold,silver, bronze, total;


		@Override
		public String toString(){
			String updateSt = "INSERT INTO SUMMEROLYMPICS VALUES(" 
					+ cid + "," + rnk + "," + year + "," + gold + "," 
					+ silver + "," + bronze + "," + total
					+ ");\n";

			return updateSt;
		}
	}
}
