package service;

import java.sql.ResultSet;
import java.util.ArrayList;

import databaseobject.ParticipationInfo;
import databaseobject.User;
import databaseobject.PersonalInfo;
import db.DBUtil;

public class ParticipationInfoService {

	
	public ArrayList<ParticipationInfo> getParticipationInformation(User user){
		
		ArrayList<ParticipationInfo> ptcp_info = new ArrayList<ParticipationInfo>();
		PersonalInfoService perinfoService = new PersonalInfoService();
		PersonalInfo pi = perinfoService.getPersonalInfobyUsrid(user.getUsrId());
		String query = "SELECT * FROM ATHELETEPARTICIPATION WHERE AID=%d";
		try{
			ResultSet rs = DBUtil.executeQuery(String.format(query, pi.getAid()));
			ParticipationInfo partInfo = null;
			while(rs.next()){
				partInfo = new ParticipationInfo();
				partInfo.setAid(rs.getInt("AID"));
				partInfo.setEventid(rs.getInt("EVENTID"));
				partInfo.setAge(rs.getInt("AGE"));
				partInfo.setTeam(rs.getString("TEAM"));
				partInfo.setRnk(rs.getString("RNK"));
				partInfo.setMedalswon(rs.getString("MEDALSWON"));
				ptcp_info.add(partInfo);
			}
			return ptcp_info;
		}
		catch(Exception e){}
		
		return null;
	}
	
	
	public ArrayList<Integer> getOtherParticipantsOfSameTeam(User usr){
	
		PersonalInfoService pis = new PersonalInfoService();
		PersonalInfo pi = pis.getPersonalInfobyUsrid(usr.getUsrId());
		ArrayList<ParticipationInfo> eventsParticipated = new ArrayList<ParticipationInfo>();
		ArrayList<Integer> aidsOfTeamMates = new ArrayList<Integer>();
		ArrayList<Integer> eventTeamMates = null;
		for(ParticipationInfo evnt : eventsParticipated){
			eventTeamMates = getEventTeamMates(evnt);
			aidsOfTeamMates.addAll(eventTeamMates);
		}
		return aidsOfTeamMates;
	}


	private ArrayList<Integer> getEventTeamMates(ParticipationInfo evnt) {

		String query = "select aid from atheleteparticipation where eventid=%d" +
				" and  team = '%s' and aid<>%d";
		try{
			
			ArrayList<Integer> evntTeamMates = new ArrayList<Integer>();
			ResultSet rs = DBUtil.executeQuery(String.format(query,evnt.getEventid(),
					evnt.getTeam(),evnt.getAid()));
			while(rs.next()){
				evntTeamMates.add(rs.getInt("AID"));
			}
			return evntTeamMates;
		}
		catch(Exception e){}
		return null;
	}
	
	
	
	
	
	
}
