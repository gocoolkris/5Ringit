package servlets;

import java.util.ArrayList;
import java.util.Date;

import org.apache.velocity.Template;
import org.apache.velocity.servlet.VelocityServlet;
import org.apache.velocity.app.Velocity;
import org.apache.velocity.context.Context;

import service.CommentService;
import service.FollowerService;
import service.LikeDislikeService;
import service.PersonalInfoService;
import service.PostService;
import service.UserService;

import javax.servlet.http.*;
import frontEndObject.Entry;
import frontEndObject.TmpAthleteData;
import databaseobject.Post;
import databaseobject.User;
import frontEndObject.AtheleteObject;;

public class Profile extends VelocityServlet {

	private final int totalPosts = 100;
	private final int numPostsPerPage = 6;
	private final int followingListLimit = 20;


	public Template handleRequest( HttpServletRequest request,
			HttpServletResponse response,
			Context context ) {

		UserService userService = new UserService();
		FollowerService fservice = new FollowerService();
		LikeDislikeService ldService = new LikeDislikeService();
		CommentService commentService = new CommentService();

		String userName = request.getParameter("username");
		String mode = request.getParameter("mode");
		HttpSession session = request.getSession();
		boolean hasAttribute = false;

		int pageNum = 1;
		String pageString = request.getParameter("page");
		if(pageString!=null) {
			pageNum = Integer.parseInt(pageString);
		}

		String currentUser = null;
		if(!session.isNew() && session.getAttribute("username")!=null) {
			currentUser = (String)session.getAttribute("username"); 
			hasAttribute =  new PersonalInfoService().isAthelete(userService.getUserbyUsername(userName));

		}else {
			try {
				response.sendRedirect("/index?msg=unloggedin");
				return null;
			}catch(Exception e) {
				e.printStackTrace();
			}
		}

		PostService postService = null;
		try {
			postService = new PostService();
		}catch(Exception e) {
			e.printStackTrace();
		}


		boolean followed = fservice.isfollowing(userService.getUserbyUsername(currentUser), 
				userService.getUserbyUsername(userName));



		ArrayList<AtheleteObject> athleteInfo = null;
		ArrayList<Post> posts = null;
		if(mode == null || mode.equals("posts")) {
			posts = postService.getAllPostsforUser(userService.getUserbyUsername(userName),totalPosts);
		}else if(mode.equals("likes")) {
			posts = ldService.getAllLikedPostforUser(userService.getUserbyUsername(userName),totalPosts);
		}else if(mode.equals("dislikes")) {
			posts = ldService.getAllDisLikedPostforUser(userService.getUserbyUsername(userName),totalPosts);
		}else if(mode.equals("comments")) {
			posts = commentService.getAllCommentedPostforUser(userService.getUserbyUsername(userName),totalPosts);
		}else if(mode.equals("attributes")) {
			athleteInfo = userService.getProfileInformation(userService.getUserbyUsername(userName));
		}
		else {
			System.out.println("mode = "+mode);
			posts = postService.getAllPostsforUser(userService.getUserbyUsername(userName),totalPosts);
		}

		ArrayList<Entry> entriesTmp = new ArrayList<Entry>();
		ArrayList<Entry> entries = new ArrayList<Entry>();
		if(posts!=null){
			entriesTmp = Entry.getEntries(posts);
		}
		for(int i = 0; i< entriesTmp.size(); i++) {
			Entry e = entriesTmp.get(i);
			String postIDVote = (String)session.getAttribute(Integer.toString(e.getId()));
			//System.out.println("postIDVote:"+postIDVote);
			e.setIsLiked(false);
			e.setIsDisliked(false);
			if(postIDVote!=null) {
				if(postIDVote.equals("like")) {
					e.setIsLiked(true);
				}
				if(postIDVote.equals("dislike")) {
					e.setIsDisliked(true);
				}
			}
			entries.add(e);
		}	


		//create fake entries object
		//ArrayList<Post> posts = new ArrayList<Post>();
		/*
		 ArrayList<Entry> entries = new ArrayList<Entry>();
		 Date tmp = new Date();
		 for (int i=0; i<totalPosts; i++) {
			 entries.add(Entry.getFakeEntry(i));			
		 }

		 ArrayList<TmpAthleteData> athleteInfo = TmpAthleteData.getFakeAthleteData(10);
		 */
		//end

		ArrayList<Entry> entriesPage = new ArrayList<Entry>();

		for(int i=numPostsPerPage*(pageNum-1); i < numPostsPerPage*pageNum && i < entries.size(); i++) {
			entriesPage.add(entries.get(i));
		}

		int totalNumOfPages = entries.size()/numPostsPerPage;

		//		int[] pages = new int[totalNumOfPages];
		//		for(int i=1; i<=totalNumOfPages; i++) {
		//			pages[i-1] = i;
		//		}

		ArrayList<Integer> pages = new ArrayList<Integer>();
		for(int i=pageNum-2; i<pageNum+3; i++) {
			if(i>0 & i<totalNumOfPages) {
				pages.add(i);
			}

		}


		ArrayList<User> followeeList = fservice.getFolloweeList(userService.getUserbyUsername(userName));
		ArrayList<User> followerList = fservice.getFollowerList(userService.getUserbyUsername(userName));


		/*
		//faking followingList
		ArrayList<User> followingList = new ArrayList<User>();
		ArrayList<User> followerList = new ArrayList<User>();
		for(int i=0; i<followingListLimit; i++) {
			User followee = new User("Estrella", "Estrella");
			User follower = new User("Obama", "Obama");
			followingList.add(followee);
			followerList.add(follower);
		}
		//end
		 */

		Template template = null;

		try {

			context.put("userName", userName);
			context.put("currentUser", currentUser);
			context.put("followed", "true");
			context.put("currentPage", pageNum);
			context.put("pages", pages);
			context.put("totalPages", totalNumOfPages);
			context.put("followingList", followeeList);
			context.put("entries", entriesPage);
			context.put("followerList", followerList);
			context.put("attributes", athleteInfo);
			context.put("hasAttribute", hasAttribute);
			context.put("followed", followed);
			context.put("mode", mode);
			template = Velocity.getTemplate("user.html");


		} catch( Exception e ) {
			System.err.println("Exception caught: " + e.getMessage());
		}

		return template;


	}
}
