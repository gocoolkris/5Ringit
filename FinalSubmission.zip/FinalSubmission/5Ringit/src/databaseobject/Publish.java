package databaseobject;

import java.sql.Timestamp;

public class Publish {
	int uid;
	int pid;
	Timestamp time;
}
